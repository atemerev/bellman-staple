Ancillary files for "An improved upper bound for Bellman's lost-in-a-forest
problem in isosceles triangles" (A. Temerev).

  tight_staple_proof.py       Verifies Theorem 3 (the golden gnomon):
                              reconstructs the Minkowski sum W in the field
                              Q(sqrt5, sqrt(10-2*sqrt5)), determines the exact
                              algebraic signs of the twelve edge certificates
                              of Table 1, and checks the length comparisons.
                              Expected output: "ALL CERTIFICATES PASS".
                              Runtime: ~2 minutes.

  interval_construction.json  The 51 rational coefficients of the piecewise-
                              polynomial staple family S(u) of Theorem 1
                              (printed in Appendix A of the paper), together
                              with the fixed support-test vertex choices used
                              in the escape certificates.

  interval_certificate.py     Verifies all 116 Sturm certificates of
                              Theorem 1 and Corollary 2: re-derives every
                              polynomial from the construction data and the
                              exact triangle geometry, then checks strict
                              positivity on each rational interval by endpoint
                              signs and exact root counts.
                              Expected output: "116/116 certificates PASS".
                              Runtime: ~10-15 minutes.

Requirements: Python 3.9+, sympy, numpy, scipy.
Code and data are also maintained at
https://github.com/atemerev/bellman-staple
